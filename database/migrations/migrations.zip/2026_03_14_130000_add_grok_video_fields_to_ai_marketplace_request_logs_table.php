<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_marketplace_request_logs', function (Blueprint $table) {
            $table->string('provider', 32)->nullable()->after('marketplace')->index();
            $table->string('external_request_id', 128)->nullable()->after('provider')->index();
            $table->string('generation_status', 32)->nullable()->after('response_type')->index();
            $table->json('response_videos')->nullable()->after('response_images');
            $table->unsignedSmallInteger('videos_count')->default(0)->after('images_count');
            $table->timestamp('limit_consumed_at')->nullable()->after('created_at');
            $table->timestamp('updated_at')->nullable()->after('limit_consumed_at');

            $table->index(['subscriber_id', 'provider', 'external_request_id'], 'ai_marketplace_sub_provider_req_idx');
        });
    }

    public function down(): void
    {
        Schema::table('ai_marketplace_request_logs', function (Blueprint $table) {
            $table->dropIndex('ai_marketplace_sub_provider_req_idx');
            $table->dropColumn([
                'provider',
                'external_request_id',
                'generation_status',
                'response_videos',
                'videos_count',
                'limit_consumed_at',
                'updated_at',
            ]);
        });
    }
};
