<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Изменяем тип поля status на string(20) для поддержки всех статусов из PaymentStatusEnum
        // CREATE, FAILED, CANCELED, CONFIRMED, RETURNED
        DB::statement("ALTER TABLE payments_transactions MODIFY COLUMN status VARCHAR(20) DEFAULT 'CREATE'");
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Возврат к enum невозможен без потери данных, оставляем как есть
    }
};
