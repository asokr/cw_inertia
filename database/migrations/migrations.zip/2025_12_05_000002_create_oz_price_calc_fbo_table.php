<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('oz_price_calc_fbo', function (Blueprint $table) {
            $table->id(); 
            $table->foreignId('cabinet_id')
                ->constrained('oz_price_calc_cabinets')
                ->cascadeOnDelete();
            $table->string('ozon_article')->nullable();
            $table->string('barcode')->nullable();
            $table->decimal('cost_price', 12, 2)->nullable();
            $table->decimal('margin_percent', 6, 2)->nullable();
            $table->decimal('fulfillment_fee', 12, 2)->nullable();
            $table->decimal('dop_rashod_percent', 6, 2)->nullable();
            $table->decimal('stop_price', 12, 2)->nullable();
            $table->decimal('weight_kg', 10, 3)->nullable();
            $table->decimal('length_cm', 10, 2)->nullable();
            $table->decimal('width_cm', 10, 2)->nullable();
            $table->decimal('height_cm', 10, 2)->nullable();
            $table->decimal('volume_liters', 10, 3)->nullable();
            $table->decimal('logistics_markup_percent', 6, 2)->nullable();
            $table->decimal('buyout_percent', 6, 2)->nullable();
            $table->decimal('logistics_fbo', 12, 2)->nullable();
            $table->decimal('logistics_fbo_over_190', 12, 2)->nullable();
            $table->decimal('acceptance_fbo', 12, 2)->nullable();
            $table->decimal('price_markup_for_logistics_percent', 6, 2)->nullable();
            $table->decimal('tax_percent', 6, 2)->nullable();
            $table->decimal('commission_percent', 6, 2)->nullable();
            $table->decimal('advertising_percent', 6, 2)->nullable();
            $table->decimal('promotion_percent', 6, 2)->nullable();
            $table->decimal('min_price', 12, 2)->nullable();
            $table->decimal('current_price', 12, 2)->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('oz_price_calc_fbo');
    }
};
