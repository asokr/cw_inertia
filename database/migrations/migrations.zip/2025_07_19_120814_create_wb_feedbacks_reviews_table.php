<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_feedbacks_reviews', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cabinet_id')->comment('ID кабинета из subs_wb_feedbacks_clients');
            $table->foreign('cabinet_id')->references('id')->on('subs_wb_feedbacks_clients')->cascadeOnDelete();
            $table->unsignedBigInteger('product_id')->comment('ID товара');
            $table->tinyInteger('rating')->comment('Оценка отзыва (1-5)');
            $table->text('content')->comment('Текст отзыва');
            $table->text('pros')->nullable()->comment('Достоинства товара, указанные покупателем');
            $table->text('cons')->nullable()->comment('Недостатки товара, указанные покупателем');
            $table->json('bables')->nullable()->comment('Впечатления покупателя про товар');
            $table->json('photo_links')->nullable()->comment('Ссылки на фотографии отзыва');
            $table->string('matching_size')->nullable()->comment('Соответствие размера');
            $table->string('color')->nullable()->comment('Цвет товара');
            $table->string('subject_name')->nullable()->comment('Категория товара');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_feedbacks_reviews');
    }
};
