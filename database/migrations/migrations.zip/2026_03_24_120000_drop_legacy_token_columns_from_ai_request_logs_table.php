<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_request_logs', function (Blueprint $table) {
            if (Schema::hasColumn('ai_request_logs', 'prompt_tokens')) {
                $table->dropColumn('prompt_tokens');
            }

            if (Schema::hasColumn('ai_request_logs', 'candidates_tokens')) {
                $table->dropColumn('candidates_tokens');
            }

            if (Schema::hasColumn('ai_request_logs', 'total_tokens')) {
                $table->dropColumn('total_tokens');
            }
        });
    }

    public function down(): void
    {
        Schema::table('ai_request_logs', function (Blueprint $table) {
            if (! Schema::hasColumn('ai_request_logs', 'prompt_tokens')) {
                $table->unsignedInteger('prompt_tokens')->nullable()->after('output_tokens');
            }

            if (! Schema::hasColumn('ai_request_logs', 'candidates_tokens')) {
                $table->unsignedInteger('candidates_tokens')->nullable()->after('prompt_tokens');
            }

            if (! Schema::hasColumn('ai_request_logs', 'total_tokens')) {
                $table->unsignedInteger('total_tokens')->nullable()->after('candidates_tokens');
            }
        });
    }
};
