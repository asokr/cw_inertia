<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('wb_repricer_cabinets')) {
            return;
        }

        if (! Schema::hasColumn('wb_repricer_cabinets', 'error_code')) {
            Schema::table('wb_repricer_cabinets', function (Blueprint $table) {
                $table->integer('error_code')->nullable()->after('apikey');
            });
        }

        if (! Schema::hasColumn('wb_repricer_cabinets', 'error_message')) {
            Schema::table('wb_repricer_cabinets', function (Blueprint $table) {
                $table->text('error_message')->nullable()->after('error_code');
            });
        }
    }

    public function down(): void
    {
        if (! Schema::hasTable('wb_repricer_cabinets')) {
            return;
        }

        if (Schema::hasColumn('wb_repricer_cabinets', 'error_message')) {
            Schema::table('wb_repricer_cabinets', function (Blueprint $table) {
                $table->dropColumn('error_message');
            });
        }

        if (Schema::hasColumn('wb_repricer_cabinets', 'error_code')) {
            Schema::table('wb_repricer_cabinets', function (Blueprint $table) {
                $table->dropColumn('error_code');
            });
        }
    }
};
