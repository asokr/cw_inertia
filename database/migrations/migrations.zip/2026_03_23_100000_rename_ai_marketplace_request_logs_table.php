<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ai_marketplace_request_logs') && ! Schema::hasTable('ai_request_logs')) {
            Schema::rename('ai_marketplace_request_logs', 'ai_request_logs');
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ai_request_logs') && ! Schema::hasTable('ai_marketplace_request_logs')) {
            Schema::rename('ai_request_logs', 'ai_marketplace_request_logs');
        }
    }
};
