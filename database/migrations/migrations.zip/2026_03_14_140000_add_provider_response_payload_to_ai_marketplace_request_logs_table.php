<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_marketplace_request_logs', function (Blueprint $table) {
            $table->json('provider_response_payload')->nullable()->after('request_payload');
        });
    }

    public function down(): void
    {
        Schema::table('ai_marketplace_request_logs', function (Blueprint $table) {
            $table->dropColumn('provider_response_payload');
        });
    }
};
