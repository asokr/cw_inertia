<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('wp_price_special_data', function (Blueprint $table) {
            $table->renameColumn('fullfilment', 'acquiring_fee');
        });
    }

    public function down(): void
    {
        Schema::table('wp_price_special_data', function (Blueprint $table) {
            $table->renameColumn('acquiring_fee', 'fullfilment');
        });
    }
};
