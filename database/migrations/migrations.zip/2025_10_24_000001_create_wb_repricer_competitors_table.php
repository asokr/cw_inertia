<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('wb_repricer_competitors', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cabinet_id')->index();
            $table->unsignedBigInteger('nm_id')->index();
            $table->decimal('base_value', 12, 2)->nullable();
            $table->decimal('base_discount', 5, 2)->nullable();
            $table->json('product_data')->nullable();
            $table->json('competitors')->nullable();
            $table->decimal('difference', 12, 2)->nullable();
            $table->enum('difference_type', ['percent', 'amount'])->nullable();
            $table->enum('competitors_price_type', ['min', 'average', 'max'])->nullable();
            $table->boolean('status')->default(false);
            $table->unsignedInteger('repeats_counter')->default(0);
            $table->timestamps();
        });

        Schema::table('wb_repricer_competitors', function (Blueprint $table) {
            $table->foreign('cabinet_id')->references('id')->on('wb_repricer_cabinets')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('wb_repricer_competitors');
    }
};
