<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wb_profitability_reports', function (Blueprint $table) {
            // Новые поля для общей таблицы
            $table->decimal('correction_sales', 14, 2)->default(0)->after('logistics');
            $table->decimal('itog',              14, 2)->default(0)->after('total_profitability');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('wb_profitability_reports', function (Blueprint $table) {
            $table->dropColumn(['correction_sales', 'itog']);
        });
    }
};
