<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_marketplace_request_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->unsignedBigInteger('subscriber_id')->nullable()->index();
            $table->string('task_type', 64)->index();
            $table->string('marketplace', 32)->nullable()->index();
            $table->json('request_payload')->nullable();
            $table->string('response_type', 16)->nullable();
            $table->unsignedSmallInteger('images_count')->default(0);
            $table->unsignedInteger('prompt_tokens')->nullable();
            $table->unsignedInteger('candidates_tokens')->nullable();
            $table->unsignedInteger('total_tokens')->nullable();
            $table->smallInteger('status_code')->default(200)->index();
            $table->text('error_message')->nullable();
            $table->timestamp('created_at')->useCurrent()->index();

            $table->index(['subscriber_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_marketplace_request_logs');
    }
};
