<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_repricer_stocks', function (Blueprint $table) {
            $table->id();
            $table->string('name', 1000)->default('');
            $table->bigInteger('cabinet_id')->unsigned();
            $table->bigInteger('nmID')->unsigned();
            $table->integer('base_value')->nullable();
            $table->integer('base_discount')->default(0);
            $table->tinyInteger('strategy')->default(1);
            $table->boolean('editable_size_price')->default(0);
            $table->json('terms')->nullable();
            $table->integer('added_value')->nullable();
            $table->boolean('active')->default(0);
            $table->boolean('status')->default(0);
            $table->integer('repeats_counter')->default(0);
            $table->timestamps();
        });

        Schema::table('wb_repricer_stocks', function ($table) {
            $table->foreign('cabinet_id')
                ->references('id')
                ->on('wb_repricer_cabinets')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_repricer_stocks');
    }
};
