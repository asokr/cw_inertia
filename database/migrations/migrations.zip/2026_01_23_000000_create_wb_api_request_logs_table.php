<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('wb_api_request_logs', function (Blueprint $table) {
            $table->id();
            $table->string('seller_id')->nullable()->index();
            $table->string('api_key_hash', 64)->index();
            $table->text('api_key')->nullable();
            $table->string('method', 10)->nullable();
            $table->string('endpoint', 500)->nullable();
            $table->json('request_data')->nullable();
            $table->smallInteger('response_code')->nullable();
            $table->timestamp('created_at')->useCurrent()->index();

            $table->index(['seller_id', 'created_at']);
            $table->index(['api_key_hash', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('wb_api_request_logs');
    }
};
