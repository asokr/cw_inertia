<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('wb_repricer_competitors', function (Blueprint $table) {
            $table->boolean('active')->default(false)->after('competitors_price_type');
        });
    }

    public function down(): void
    {
        Schema::table('wb_repricer_competitors', function (Blueprint $table) {
            $table->dropColumn('active');
        });
    }
};
