<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('wb_price_calc_v2_settings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cabinet_id')
                ->constrained('wb_price_cabinets')
                ->cascadeOnDelete();

            // --- Тип расчёта "% за ведение" ---
            // 'transfer' = от суммы к перечислению на р/с, 'sales' = от суммы продаж
            $table->enum('maintenance_type', ['transfer', 'sales'])->default('transfer');

            // --- Настройка "% выкупа" ---
            // 'cabinet' = единый на кабинет, 'article' = на каждый артикул отдельно
            $table->enum('buyout_scope', ['cabinet', 'article'])->default('cabinet');

            // --- Индекс локализации ---
            // true = учитывать (подтягиваем с портала: Поставки и заказы → Тарифы), false = не учитывать (ставим 1)
            $table->boolean('use_localization_index')->default(false);

            // --- Хранение ---
            // true = учитывать, false = не учитывать
            $table->boolean('use_storage')->default(false);

            // --- Источник комиссии WB ---
            // 'fbs' = FBS (kgvpMarketplace), 'fbo' = FBO (paidStorageKgvp), 'reports' = из фин. отчетов, 'manual' = вручную (загрузка Excel на каждый товар)
            $table->enum('commission_source', ['fbs', 'fbo', 'reports', 'manual'])->default('fbs');

            // --- Источник эквайринга ---
            // 'reports' = из фин. отчетов, 'manual' = вручную (загрузка Excel на каждый товар)
            $table->enum('acquiring_source', ['reports', 'manual'])->default('manual');

            $table->timestamps();

            $table->unique('cabinet_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('wb_price_calc_v2_settings');
    }
};
