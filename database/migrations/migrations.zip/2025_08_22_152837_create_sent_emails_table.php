<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sent_emails', function (Blueprint $table) {
            $table->id();
            $table->string('to')->index();
            $table->string('subject');
            $table->text('body');
            $table->string('type')->nullable(); // system, notification, etc.
            $table->string('status')->default('sent'); // sent, failed, etc.
            $table->text('error_message')->nullable();
            $table->json('meta')->nullable(); // дополнительные данные
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sent_emails');
    }
};
