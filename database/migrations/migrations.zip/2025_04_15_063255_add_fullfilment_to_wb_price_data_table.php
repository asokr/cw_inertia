<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('wb_price_data', function (Blueprint $table) {
            $table->decimal('fullfilment', 7, 2)->after('profit')->default(0)->comment('Расходы ФФ');
        });
    }

    public function down(): void
    {
        Schema::table('wb_price_data', function (Blueprint $table) {
            $table->dropColumn('fullfilment');
        });
    }
};
