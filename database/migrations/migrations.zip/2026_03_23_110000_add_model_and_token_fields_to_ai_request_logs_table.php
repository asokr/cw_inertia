<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_request_logs', function (Blueprint $table) {
            if (! Schema::hasColumn('ai_request_logs', 'model')) {
                $table->string('model', 128)->nullable()->after('provider')->index();
            }

            if (! Schema::hasColumn('ai_request_logs', 'input_tokens')) {
                $table->unsignedBigInteger('input_tokens')->nullable()->after('videos_count');
            }

            if (! Schema::hasColumn('ai_request_logs', 'output_tokens')) {
                $table->unsignedBigInteger('output_tokens')->nullable()->after('input_tokens');
            }
        });
    }

    public function down(): void
    {
        Schema::table('ai_request_logs', function (Blueprint $table) {
            if (Schema::hasColumn('ai_request_logs', 'model')) {
                $table->dropColumn('model');
            }

            if (Schema::hasColumn('ai_request_logs', 'input_tokens')) {
                $table->dropColumn('input_tokens');
            }

            if (Schema::hasColumn('ai_request_logs', 'output_tokens')) {
                $table->dropColumn('output_tokens');
            }
        });
    }
};
