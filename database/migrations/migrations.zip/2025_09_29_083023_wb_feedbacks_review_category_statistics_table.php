<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_feedbacks_review_category_statistics', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cabinet_id')->index();
            $table->string('subject_name')->index(); // Категория/предмет WB
            $table->date('date')->index();           // Якорь периода (1-е число месяца или начало недели)
            $table->string('stat_type', 16)->index(); // weekly | monthly | yearly | general
            $table->json('stat_data');               // KPI + распределения + ai_* по категории
            $table->timestamps();

            $table->unique(
                ['cabinet_id', 'subject_name', 'date', 'stat_type'],
                'wbrcs_cab_subj_date_type_unique'
            );
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_feedbacks_review_category_statistics');
    }
};
