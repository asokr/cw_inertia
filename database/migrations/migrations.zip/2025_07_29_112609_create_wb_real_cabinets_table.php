<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_real_cabinets', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            // Владелец аккаунта
            $table->foreignId('user_id')
                ->constrained('users')
                ->cascadeOnDelete();

            // Номер телефона для логина и отправки OTP
            $table->string('phone')->unique();

            $table->string('country')->nullable();

            // Текущий статус сессии
            $table->enum('status', [
                'inactive',
                'waiting_otp',
                'verifying_otp',
                'failing_otp',
                'active',
                'reauth_required',
            ])->default('inactive');
            $table->string('session_status', 32)
                ->nullable()
                ->default(null)
                ->comment('Статус сессии Puppeteer: active, pending, failed, closed');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_real_cabinets');
    }
};
