<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('oz_feedbacks_clients', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id')->unsigned();
            $table->string('name', 120);
            $table->integer('client_id')->unsigned();
            $table->string('apikey', 1500);
            $table->boolean('bot_status')->default(0);
            $table->boolean('ai_status')->default(0);
            $table->boolean('empty_answer')->default(0);
            $table->string('signature', 300)->nullable();
            $table->json('ai_ratings')->nullable();
            $table->timestamps();
        });

        Schema::table('oz_feedbacks_clients', function ($table) {
            $table->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('oz_feedbacks_clients');
    }
};
