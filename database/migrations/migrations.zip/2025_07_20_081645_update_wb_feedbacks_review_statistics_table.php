<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateWbFeedbacksReviewStatisticsTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wb_feedbacks_review_statistics', function (Blueprint $table) {
            // Удаляем внешний ключ для top_product_id
            $table->dropForeign(['top_product_id']);

            // Удаляем фиксированные колонки
            $table->dropColumn(['total_reviews', 'average_rating', 'total_responses', 'top_product_id']);

            $table->string('stat_type')->after('date')->default('general')->comment('Тип статистики: weekly, monthly, yearly, general');

            // Добавляем новое поле JSON для хранения данных статистики
            $table->json('stat_data')->after('date')->nullable()->comment('Данные статистики в формате JSON');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('wb_feedbacks_review_statistics', function (Blueprint $table) {
            // Восстанавливаем удалённые колонки
            $table->integer('total_reviews')->default(0)->comment('Общее количество отзывов');
            $table->decimal('average_rating', 3, 2)->default(0)->comment('Средняя оценка');
            $table->integer('total_responses')->default(0)->comment('Количество ответов бота');
            $table->unsignedBigInteger('top_product_id')->nullable()->comment('Товар с наибольшим количеством отзывов');

            // Восстанавливаем внешний ключ
            $table->foreign('top_product_id')->references('id')->on('wb_feedbacks_products')->nullOnDelete();

            // Удаляем поле JSON
            $table->dropColumn('stat_data');
        });
    }
}
