<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('wb_price_calc_v2_data', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cabinet_id')
                ->constrained('wb_price_cabinets')
                ->cascadeOnDelete();

            // --- Данные товара (подтягиваются из API) ---
            $table->string('brand')->nullable();                                    // Бренд
            $table->string('subject_name')->nullable();                             // Предмет (категория)
            $table->string('vendor_code')->nullable();                              // Артикул продавца
            $table->unsignedBigInteger('nm_id')->nullable();                        // Артикул WB
            $table->string('size')->nullable();                                     // Размер
            $table->string('barcode')->nullable();                                  // Баркод
            $table->decimal('volume_liters', 10, 3)->nullable();                    // Объем, л.
            $table->decimal('extra_liters', 10, 3)->nullable();                     // Доп. литры сверх 1 л

            // --- Заполняется пользователем с фронта ---
            $table->decimal('cost_price', 12, 2)->nullable();                       // Себестоимость, руб.
            $table->decimal('margin_percent', 6, 2)->nullable();                    // Маржа, %
            $table->decimal('fulfillment_fee', 12, 2)->nullable();                  // Услуги ФФ, руб./ед.
            $table->decimal('maintenance_percent', 6, 2)->nullable();               // % за ведение (тип: от суммы к перечислению или от суммы продаж)

            // --- Расчётные поля ---
            $table->decimal('stop_price', 12, 2)->nullable();                       // СТОП-ЦЕНА, руб.
            $table->decimal('avg_base_logistics', 12, 2)->nullable();               // Ср. базовая логистика
            $table->decimal('avg_extra_liter_logistics', 12, 2)->nullable();        // Ср. логистика за доп. литр
            $table->decimal('avg_logistics', 12, 2)->nullable();                    // Средняя логистика, руб.
            $table->decimal('return_cost', 12, 2)->nullable();                      // ВОЗВРАТ, руб.
            $table->decimal('buyout_percent', 6, 2)->nullable();                    // % выкупа
            $table->decimal('localization_index', 8, 4)->default(1.0000);           // Индекс локализации (1 = не учитывать)
            $table->decimal('total_logistics', 12, 2)->nullable();                  // ИТОГОВАЯ ЛОГИСТИКА, руб.
            $table->decimal('storage_cost', 12, 2)->nullable();                     // Хранение, руб.
            $table->unsignedInteger('sales_count')->nullable();                     // Продажи, шт.
            $table->decimal('storage_per_sale', 12, 2)->nullable();                 // Хранение / 1 продажа, руб.
            $table->decimal('advertising_percent', 6, 2)->nullable();               // ДРР, % от оборота (% от цены продажи 1 ед. на рекламу)
            $table->decimal('wb_commission_percent', 6, 2)->nullable();             // Комиссия ВБ (FBS/FBO/вручную/из фин. отчетов)
            $table->decimal('acquiring_percent', 6, 2)->nullable();                 // Эквайринг, %
            $table->decimal('commission_plus_acquiring', 6, 2)->nullable();         // Комиссия + Эквайринг, %

            // --- Заполняется пользователем ---
            $table->decimal('tax_percent', 6, 2)->nullable();                       // % налога
            $table->decimal('standard_discount_percent', 6, 2)->nullable();         // Стандартная скидка для покупателя, %
            $table->decimal('promotion_percent', 6, 2)->nullable();                 // % на участие в акции

            // --- Итоговые рассчитанные цены ---
            $table->decimal('min_price_promo', 12, 2)->nullable();                  // Минимальная цена (для акций)
            $table->decimal('standard_price', 12, 2)->nullable();                   // Стандартная цена (без акций)
            $table->decimal('price_before_discount', 12, 2)->nullable();            // Цена до скидки

            $table->softDeletes();
            $table->timestamps();

            // Индексы для часто запрашиваемых полей
            $table->index('nm_id');
            $table->index('barcode');
            $table->index('vendor_code');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('wb_price_calc_v2_data');
    }
};
