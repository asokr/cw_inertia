<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('wb_autosupply_cabinets', function (Blueprint $table) {
            $table->unsignedBigInteger('real_cabinet_id')->nullable()->after('apikey');

            // Если у тебя другое имя таблицы реальных кабинетов — поправь тут.
            $table->foreign('real_cabinet_id')
                ->references('id')
                ->on('wb_real_cabinets')
                ->cascadeOnUpdate()
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('wb_autosupply_cabinets', function (Blueprint $table) {
            $table->dropForeign(['real_cabinet_id']);
            $table->dropColumn('real_cabinet_id');
        });
    }
};
