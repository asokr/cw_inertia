<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_costs', function (Blueprint $table) {
            $table->id();
            $table->date('date')->index();
            $table->string('provider', 32)->index();
            $table->string('model', 128)->nullable();
            $table->string('task_type', 64);
            $table->unsignedInteger('requests_count')->default(0);
            $table->unsignedBigInteger('input_tokens')->default(0);
            $table->unsignedBigInteger('output_tokens')->default(0);
            $table->unsignedInteger('images_count')->default(0);
            $table->unsignedInteger('videos_seconds')->default(0);
            $table->decimal('cost', 12, 6)->default(0);
            $table->timestamps();

            $table->index(['date', 'provider', 'model', 'task_type'], 'ai_costs_aggregate_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_costs');
    }
};
