<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_autosupply_cabinets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('name');
            $table->string('apikey', 1500);
            $table->unsignedBigInteger('real_cabinet_id')->nullable();
            $table->string('legal_entity_id');
            $table->string('legal_entity_name');
            $table->timestamps();

            $table->foreign('real_cabinet_id')
                ->references('id')
                ->on('wb_real_cabinets')
                ->cascadeOnUpdate()
                ->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_autosupply_cabinets');
    }
};
