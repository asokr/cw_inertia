<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wb_price_calc_v2_settings', function (Blueprint $table) {
            $table->boolean('hide_sizes')->default(true)->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('wb_price_calc_v2_settings', function (Blueprint $table) {
            $table->boolean('hide_sizes')->default(false)->change();
        });
    }
};
