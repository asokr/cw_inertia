<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_repricer_settings', function (Blueprint $table) {
            $table->id();
            $table->string('name', 1000)->default('');
            $table->bigInteger('cabinet_id')->unsigned();
            $table->bigInteger('nmID')->unsigned();
            $table->integer('base_value')->nullable();
            $table->enum('price_type', ['PRICE', 'DISCOUNT'])->default('PRICE');
            $table->string('strategy')->default('TIME');
            $table->enum('pricing_modifier_type', ['FIXED', 'PROCENT'])->default('FIXED');
            $table->json('terms')->nullable();
            $table->boolean('active')->default(0);
            $table->boolean('status')->default(0);
            $table->timestamps();
        });

        Schema::table('wb_repricer_settings', function ($table) {
            $table->foreign('cabinet_id')
                ->references('id')
                ->on('wb_repricer_cabinets')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_repricer_settings');
    }
};
