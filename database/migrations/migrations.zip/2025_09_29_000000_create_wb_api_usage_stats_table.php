<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_api_usage_stats', function (Blueprint $table) {
            $table->id();
            $table->date('stat_date');
            $table->string('api_key_hash', 64);
            $table->text('api_key')->nullable();
            $table->unsignedBigInteger('requests_count')->default(0);
            $table->string('legal_entity')->nullable();
            $table->string('seller_id')->nullable();
            $table->timestamp('legal_entity_synced_at')->nullable();
            $table->timestamps();

            $table->unique(['api_key_hash', 'stat_date']);
            $table->index('stat_date');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_api_usage_stats');
    }
};
