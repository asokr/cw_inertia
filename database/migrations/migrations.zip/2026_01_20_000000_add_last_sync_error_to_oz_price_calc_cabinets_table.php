<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('oz_price_calc_cabinets', function (Blueprint $table) {
            if (!Schema::hasColumn('oz_price_calc_cabinets', 'last_sync_error')) {
                $table->text('last_sync_error')->nullable()->after('apikey');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('oz_price_calc_cabinets', function (Blueprint $table) {
            $table->dropColumn('last_sync_error');
        });
    }
};
