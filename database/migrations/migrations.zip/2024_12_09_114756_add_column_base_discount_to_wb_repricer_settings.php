<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wb_repricer_settings', function (Blueprint $table) {
            $table->integer('base_discount')->default(0)->after('base_value');
            $table->integer('repeats_counter')->default(0)->after('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('wb_repricer_settings', function (Blueprint $table) {
            if (Schema::hasColumn('wb_repricer_settings', 'base_discount')) {
                $table->dropColumn('base_discount');
            }
            if (Schema::hasColumn('wb_repricer_settings', 'repeats_counter')) {
                $table->dropColumn('repeats_counter');
            }
        });
    }
};
