<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_feedbacks_review_product_statistics', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cabinet_id')->index();
            $table->string('product_id', 64)->index();
            $table->date('date')->index(); // например, последний день месяца
            $table->json('stat_data');
            $table->json('pros_cons_data');
            $table->timestamps();

            $table->unique(['cabinet_id', 'product_id', 'date'], 'wb_feedbacks_review_prod_stats_unique');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_feedbacks_review_product_statistics');
    }
};
