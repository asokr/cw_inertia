<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('oz_price_calc_cabinets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('client_id'); 
            $table->text('apikey');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('oz_price_calc_cabinets');
    }
};
