<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('job_statuses', function (Blueprint $table) {
            $table->id();
            // Полное имя (FQN) класса Job, например App\Jobs\ProcessProfitabilityReport
            $table->string('job_name');
            // JSON-поле, в котором можно хранить любые данные (id кабинета, пользователь, другие параметры)
            $table->json('data')->nullable();
            // Статус задачи: например 'processing', 'done', 'failed'
            $table->string('status');
            // Текст ошибки, если задача упала
            $table->text('error')->nullable();
            $table->timestamps();

            // Индекс по job_name
            $table->index('job_name');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('job_statuses');
    }
};
