<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWbAutoSupplyItemsTable extends Migration
{
    public function up()
    {
        Schema::create('wb_autosupply_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cabinet_id')->constrained('wb_autosupply_cabinets')->onDelete('cascade');
            $table->foreignId('real_cabinet_id')->constrained('wb_real_cabinets')->onDelete('cascade');
            $table->string('preorderID')->nullable();
            $table->string('status')->default('Не запланировано');
            $table->json('data')->nullable();
            $table->dateTime('date_start')->nullable();
            $table->dateTime('date_end')->nullable();
            $table->tinyInteger('delivery_slot_offset_days')->unsigned()->default(2);
            $table->decimal('auto_booking_max_coefficient', 5, 2)->default(5.00);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('wb_auto_supplies');
    }
}
