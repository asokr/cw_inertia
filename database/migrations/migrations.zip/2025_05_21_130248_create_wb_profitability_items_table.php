<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_profitability_items', function (Blueprint $table) {
            $table->id();

            // Ссылка на отчёт
            $table->foreignId('report_id')
                ->constrained('wb_profitability_reports')
                ->cascadeOnDelete();

            // === Основные поля из заголовка «Товар» ===
            $table->string('nm_id')->nullable(); //Артикул WB
            $table->string('sa_name')->nullable(); //Артикул продавца
            $table->string('supplier_oper_name')->nullable(); //Обоснование для оплаты
            $table->string('size')->nullable(); // Размер
            $table->string('barcode')->nullable(); // Баркод
            $table->string('warehouse')->nullable(); // Склад
            $table->string('reasoning')->nullable(); // Виды логистики, штрафов и доплат. Поле будет в ответе при наличии значения

            // === Количество ===
            $table->integer('quantity')->default(0);

            // === Цена без (СПП) ===
            $table->decimal('price_without_spp', 14, 2)->default(0);

            // === Сумма к перечислению ===
            $table->decimal('sum_to_transfer', 14, 2)->default(0);

            // === Закупка ===
            $table->decimal('purchase_cost', 14, 2)->default(0);

            // === ЛОГИСТИКА ===
            $table->decimal('logistics', 14, 2)->default(0);

            // === Итог ===
            $table->decimal('item_total', 14, 2)->default(0);

            // === Затраты/доплаты ===
            $table->decimal('cost_adjustments', 14, 2)->default(0);

            // === Маржа ===
            $table->decimal('margin', 14, 2)->default(0);

            // === Рентабельность (%) ===
            $table->decimal('profitability_percent', 5, 2)->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_profitability_items');
    }
};
