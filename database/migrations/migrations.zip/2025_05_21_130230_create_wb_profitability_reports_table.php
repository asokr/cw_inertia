<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_profitability_reports', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cabinet_id')
                ->constrained('wb_profitability_cabinets')
                ->cascadeOnDelete();

            // Период
            $table->date('date_from');
            $table->date('date_to');

            // === ПРОДАЖИ ===
            $table->integer('sales_quantity')->default(0);        // количество проданных
            $table->decimal('sales_amount', 14, 2)->default(0);   // сумма продаж

            // === ВОЗВРАТЫ ===
            $table->integer('returns_quantity')->default(0);      // количество возвратов
            $table->decimal('returns_amount', 14, 2)->default(0); // сумма возвратов

            // === % ВЫКУПА ===
            $table->decimal('percent_buy', 5, 2)->default(0);     // процент выкупа

            // === ШТРАФЫ И ДОПЛАТЫ ===
            $table->decimal('penalties', 14, 2)->default(0);      // штрафы/доплаты

            // === ЛОГИСТИКА ===
            $table->decimal('logistics', 14, 2)->default(0);

            // === Закупка ===
            $table->decimal('purchase_cost', 14, 2)->default(0);

            // === Маржа ===
            $table->decimal('margin', 14, 2)->default(0);

            // === Прочие удержания/выплаты ===
            $table->decimal('deduction', 14, 2)->default(0);

            // === Хранение ===
            $table->decimal('storage_fee', 14, 2)->default(0);

            // === Платная приёмка ===
            $table->decimal('acceptance', 14, 2)->default(0);

            // === ИТОГ ===
            $table->decimal('total_profitability', 14, 2)->default(0);

            $table->timestamps();

            $table->unique(['cabinet_id'], 'wb_profit_reports_period_unique');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_profitability_reports');
    }
};
