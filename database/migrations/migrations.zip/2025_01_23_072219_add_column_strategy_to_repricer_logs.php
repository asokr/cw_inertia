<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('wb_repricer_logs', function (Blueprint $table) {
            $table->string('strategy')->default('TIME')->after('type');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('wb_repricer_logs', function (Blueprint $table) {
            if (Schema::hasColumn('wb_repricer_logs', 'strategy')) {
                $table->dropColumn('strategy');
            }
        });
    }
};
