<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_feedbacks_bot_responses', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('review_id')->comment('ID отзыва из wb_feedbacks_reviews');
            $table->foreign('review_id')->references('id')->on('wb_feedbacks_reviews')->cascadeOnDelete();
            $table->text('response_text')->comment('Ответ бота на отзыв');
            $table->boolean('is_ai_response')->default(false)->comment('Ответ сформирован ИИ (true) или шаблоном (false)');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_feedbacks_bot_responses');
    }
};
