<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ai_marketplace_request_logs', function (Blueprint $table) {
            $table->longText('response_text')->nullable()->after('request_payload');
            $table->json('response_images')->nullable()->after('response_text');
        });
    }

    public function down(): void
    {
        Schema::table('ai_marketplace_request_logs', function (Blueprint $table) {
            $table->dropColumn(['response_text', 'response_images']);
        });
    }
};
