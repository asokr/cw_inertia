<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wb_feedbacks_review_statistics', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('cabinet_id')->comment('ID кабинета из subs_wb_feedbacks_clients');
            $table->foreign('cabinet_id')->references('id')->on('subs_wb_feedbacks_clients')->cascadeOnDelete();
            $table->date('date')->comment('Дата статистики');
            $table->integer('total_reviews')->default(0)->comment('Общее количество отзывов');
            $table->decimal('average_rating', 3, 2)->default(0)->comment('Средняя оценка');
            $table->integer('total_responses')->default(0)->comment('Количество ответов бота');
            $table->unsignedBigInteger('top_product_id')->nullable()->comment('Товар с наибольшим количеством отзывов');
            $table->foreign('top_product_id')->references('id')->on('wb_feedbacks_products')->nullOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wb_feedbacks_review_statistics');
    }
};
